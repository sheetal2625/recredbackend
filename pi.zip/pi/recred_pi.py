#!/usr/bin/env python3
"""
ReCred - Raspberry Pi 5 Controller
====================================
Hardware:
  - Webcam          /dev/video0   (YOLO bottle detection)
  - Arduino UNO     /dev/ttyACM0  (IR, FSR, Servo, Reset button via UART)
  - HDMI Display    (OpenCV fullscreen UI)

Serial Protocol (115200 baud):
  UNO -> Pi :  TRIG OV=0 / TRIG OV=1 / DONE / RESET / UNO_READY
  Pi  -> UNO:  SORT L / SORT R / CENTER

Flow:
  IR triggers → UNO sends TRIG OV=x → Pi scans 5s with YOLO
  → bottle + not overweight → SORT L (+1 count)
  → not bottle OR overweight OR timeout → SORT R (reject)
  → UNO actuates servo 1s → sends DONE → Pi shows result
  → Reset button → UNO sends RESET → Pi shows QR code
"""

import time
import cv2
import numpy as np
import serial
import qrcode
from ultralytics import YOLO
import threading

# ─── CONFIG ───────────────────────────────────────────────
MODEL_PATH   = "/home/dhanu/Desktop/train/weights/best.pt"
CAM_DEVICE   = "/dev/video0"
SERIAL_PORT  = "/dev/ttyACM0"   # change to /dev/ttyUSB0 if needed
BAUD         = 115200

SERVER_URL   = "https://your-app.up.railway.app"  # ← update after deployment
POINTS_PER   = 10
QR_EXPIRY    = 30   # seconds QR stays on screen

SCAN_SECS    = 5.0  # YOLO detection window
YOLO_IMGSZ   = 416
YOLO_CONF    = 0.55
BOTTLE_LABELS = {"bottle"}

# UI
WIN   = "ReCred"
UI_W  = 800
UI_H  = 480

# Colours (BGR for OpenCV)
C = {
    "bg":      (10,  10,  10),
    "green":   (84, 185, 29),
    "yellow":  (61, 217, 253),
    "white":   (255,255,255),
    "gray":    (140,140,140),
    "red":     (80, 100, 255),
    "cyan":    (255,200,  0),
}

# ─── INIT ─────────────────────────────────────────────────
print("[ReCred] Loading YOLO model...")
model = YOLO(MODEL_PATH)
names = model.names
print("[ReCred] YOLO ready")

print(f"[ReCred] Opening camera {CAM_DEVICE}...")
cap = cv2.VideoCapture(CAM_DEVICE, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
time.sleep(0.3)
if not cap.isOpened():
    raise RuntimeError(f"[ReCred] Camera failed: {CAM_DEVICE}")
print("[ReCred] Camera ready")

print(f"[ReCred] Connecting to Arduino on {SERIAL_PORT}...")
ser = serial.Serial(SERIAL_PORT, BAUD, timeout=0.01)
time.sleep(1.5)
ser.reset_input_buffer()
print("[ReCred] Arduino connected")

cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
cv2.resizeWindow(WIN, UI_W, UI_H)
cv2.setWindowProperty(WIN, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)


# ─── UTILITY ──────────────────────────────────────────────
def pts(n):
    return n * POINTS_PER

def send(cmd: str):
    ser.write((cmd + "\n").encode())

def read_serial_lines():
    lines = []
    try:
        while ser.in_waiting:
            raw = ser.readline().decode(errors="ignore").strip()
            if raw:
                lines.append(raw)
    except Exception:
        pass
    return lines

def yolo_is_bottle(frame) -> bool:
    result = model.predict(frame, imgsz=YOLO_IMGSZ, conf=YOLO_CONF, verbose=False)[0]
    if result.boxes is None:
        return False
    for b in result.boxes:
        cls   = int(b.cls[0])
        label = str(names.get(cls, "")).lower()
        if label in BOTTLE_LABELS:
            return True
    return False

def make_qr(url: str, size=260):
    qr_img = qrcode.make(url).convert("RGB").resize((size, size))
    arr    = np.array(qr_img)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

def build_claim_url(bottles):
    exp = int(time.time()) + QR_EXPIRY
    return (f"{SERVER_URL}/claim"
            f"?bottles={bottles}"
            f"&points={pts(bottles)}"
            f"&exp={exp}")


# ─── UI DRAW FUNCTIONS ────────────────────────────────────
def text(ui, msg, x, y, scale, color, thick=2):
    cv2.putText(ui, msg, (x, y),
                cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)

def draw_main(status: str, bottles: int):
    ui = np.zeros((UI_H, UI_W, 3), dtype=np.uint8)
    ui[:] = C["bg"]

    # Header
    text(ui, "Re",    30,  70, 2.2, C["green"],  5)
    text(ui, "Cred", 140,  70, 2.2, C["yellow"], 5)

    # Bottles
    text(ui, "BOTTLES",  30, 160, 0.9, C["gray"])
    text(ui, str(bottles), 30, 265, 3.8, C["white"], 8)

    # Points
    text(ui, "POINTS",  430, 160, 0.9, C["gray"])
    text(ui, str(pts(bottles)), 430, 265, 3.8, C["green"], 8)

    # Divider line
    cv2.line(ui, (0, 300), (UI_W, 300), (40, 40, 40), 1)

    # Status
    text(ui, f"Status: {status}", 30, 360, 0.95, C["cyan"])

    # Footer
    text(ui, "Reset btn = claim points   |   Ctrl+Q = exit",
         30, 455, 0.55, C["gray"])

    cv2.imshow(WIN, ui)

def draw_wait(bottles: int):
    ui = np.zeros((UI_H, UI_W, 3), dtype=np.uint8)
    ui[:] = C["bg"]
    text(ui, "Re",    30,  70, 2.2, C["green"],  5)
    text(ui, "Cred", 140,  70, 2.2, C["yellow"], 5)
    text(ui, "PLEASE WAIT...", 150, 250, 1.6, C["cyan"], 4)
    text(ui, "Processing your bottle", 155, 310, 0.85, C["gray"])
    text(ui, f"Bottles: {bottles}   Points: {pts(bottles)}",
         240, 420, 0.8, C["white"])
    cv2.imshow(WIN, ui)

def draw_scanning(seconds_left: float, bottles: int):
    ui = np.zeros((UI_H, UI_W, 3), dtype=np.uint8)
    ui[:] = C["bg"]
    text(ui, "Re",    30,  70, 2.2, C["green"],  5)
    text(ui, "Cred", 140,  70, 2.2, C["yellow"], 5)
    text(ui, "SCANNING...", 220, 210, 1.5, C["green"], 4)
    text(ui, f"Detecting in {seconds_left:.1f}s", 240, 280, 1.0, C["white"])

    # Progress bar
    bar_w = int((1.0 - seconds_left / SCAN_SECS) * 740)
    cv2.rectangle(ui, (30, 320), (770, 345), (40, 40, 40), -1)
    cv2.rectangle(ui, (30, 320), (30 + bar_w, 345), C["green"], -1)

    text(ui, f"Bottles: {bottles}   Points: {pts(bottles)}",
         240, 420, 0.8, C["white"])
    cv2.imshow(WIN, ui)

def draw_result(accepted: bool, bottles: int, overweight: bool):
    ui = np.zeros((UI_H, UI_W, 3), dtype=np.uint8)
    ui[:] = C["bg"]
    text(ui, "Re",    30,  70, 2.2, C["green"],  5)
    text(ui, "Cred", 140,  70, 2.2, C["yellow"], 5)

    if accepted:
        text(ui, "BOTTLE ACCEPTED!",   120, 210, 1.6, C["green"],  4)
        text(ui, "+1 bottle  +10 pts", 220, 275, 1.1, C["white"])
    else:
        reason = "OVERWEIGHT (filled)" if overweight else "NOT A BOTTLE"
        text(ui, "REJECTED",           240, 210, 1.8, C["red"],   4)
        text(ui, reason,               200, 275, 1.0, C["yellow"])

    cv2.line(ui, (0, 310), (UI_W, 310), (40, 40, 40), 1)
    text(ui, "BOTTLES",  30, 380, 0.9, C["gray"])
    text(ui, str(bottles), 30, 455, 2.2, C["white"], 6)
    text(ui, "POINTS",  430, 380, 0.9, C["gray"])
    text(ui, str(pts(bottles)), 430, 455, 2.2, C["green"], 6)
    cv2.imshow(WIN, ui)

def draw_qr_screen(bottles: int, qr_bgr, seconds_left: int):
    ui = np.zeros((UI_H, UI_W, 3), dtype=np.uint8)
    ui[:] = C["bg"]
    text(ui, "Re",    30, 60, 1.8, C["green"],  4)
    text(ui, "Cred", 120, 60, 1.8, C["yellow"], 4)
    text(ui, "SCAN TO CLAIM POINTS", 30, 110, 0.85, C["white"], 2)

    text(ui, f"Bottles : {bottles}",      30, 170, 0.85, C["white"])
    text(ui, f"Points  : {pts(bottles)}", 30, 210, 0.85, C["green"])
    text(ui, f"Expires : {seconds_left}s", 30, 250, 0.8, C["yellow"])
    text(ui, "Scan QR with phone ->",    30, 310, 0.8, C["gray"])
    text(ui, "Login/Register on website", 30, 345, 0.75, C["gray"])
    text(ui, "Points added to your account", 30, 380, 0.75, C["gray"])

    if qr_bgr is not None:
        h, w = qr_bgr.shape[:2]
        y1, y2 = UI_H // 2 - h // 2, UI_H // 2 + h // 2
        x1, x2 = UI_W - w - 30, UI_W - 30
        ui[y1:y2, x1:x2] = qr_bgr

    text(ui, "Scan -> New session starts automatically",
         30, 460, 0.55, C["gray"])
    cv2.imshow(WIN, ui)


# ─── STATE ────────────────────────────────────────────────
bottles    = 0
state      = "IDLE"
status_msg = "READY - insert a bottle"

overweight  = False
scan_until  = 0.0
seen_bottle = False

wait_until        = 0.0
last_accepted     = False
last_overweight   = False

qr_bgr    = None
qr_url    = ""
qr_until  = 0.0


# ─── MAIN LOOP ────────────────────────────────────────────
print("\n[ReCred] System started. Insert bottles!")
print("         Reset button on Arduino = claim points")
print("         Ctrl+Q = exit\n")

try:
    while True:
        now = time.time()

        # ── Keyboard ──────────────────────────────────────
        k = cv2.waitKey(1) & 0xFF
        if k == 17 or k == ord('q'):    # Ctrl+Q
            break

        # ── Read Arduino serial ───────────────────────────
        for line in read_serial_lines():
            print(f"[UNO] {line}")

            # --- Object detected ---
            if line.startswith("TRIG"):
                try:
                    ov_val = int(line.split("OV=")[1])
                    overweight = (ov_val == 1)
                except Exception:
                    overweight = False

                if state == "IDLE":
                    state      = "SCAN"
                    scan_until = now + SCAN_SECS
                    seen_bottle = False
                    print(f"[Pi] Scan started. Overweight={overweight}")

            # --- Servo action complete ---
            elif line == "DONE":
                if state == "WAIT":
                    state      = "RESULT"
                    wait_until = now + 1.5   # show result for 1.5s
                    print("[Pi] Servo done, showing result")

            # --- Reset button pressed on UNO ---
            elif line == "RESET":
                if bottles > 0 and state not in ("SCAN", "WAIT"):
                    qr_url   = build_claim_url(bottles)
                    qr_bgr   = make_qr(qr_url, size=260)
                    qr_until = now + QR_EXPIRY
                    state    = "QR"
                    print(f"[Pi] QR generated: {qr_url}")
                else:
                    print("[Pi] Reset pressed but no bottles to claim")

        # ── State machine ─────────────────────────────────

        # ── SCAN: run YOLO for up to SCAN_SECS ──────────
        if state == "SCAN":
            ret, frame = cap.read()
            if ret and yolo_is_bottle(frame):
                seen_bottle = True

            secs_left = max(0.0, scan_until - now)
            draw_scanning(secs_left, bottles)

            if now >= scan_until:
                # Decision
                accepted = seen_bottle and not overweight
                if accepted:
                    bottles += 1
                    send("SORT L")
                    print("[Pi] → SORT L (accepted)")
                else:
                    send("SORT R")
                    print(f"[Pi] → SORT R (bottle={seen_bottle} overweight={overweight})")

                last_accepted   = accepted
                last_overweight = overweight

                state      = "WAIT"
                wait_until = now + 2.5   # UNO holds 1s + travel time buffer

        # ── WAIT: show "PLEASE WAIT" until DONE from UNO ─
        elif state == "WAIT":
            draw_wait(bottles)
            # Safety timeout: if UNO doesn't reply within 4s, move on
            if now > wait_until + 4.0:
                state      = "RESULT"
                wait_until = now + 1.5

        # ── RESULT: show accepted/rejected for 1.5s ───────
        elif state == "RESULT":
            draw_result(last_accepted, bottles, last_overweight)
            if now >= wait_until:
                state      = "IDLE"
                status_msg = "READY - insert a bottle"

        # ── QR: show QR until expired then reset ──────────
        elif state == "QR":
            secs_left = int(qr_until - now)
            if secs_left <= 0:
                bottles    = 0
                state      = "IDLE"
                status_msg = "READY - insert a bottle"
                print("[Pi] QR expired, session reset")
            else:
                draw_qr_screen(bottles, qr_bgr, secs_left)

        # ── IDLE: normal ready screen ─────────────────────
        else:
            draw_main(status_msg, bottles)

finally:
    print("\n[ReCred] Shutting down...")
    try:
        send("CENTER")
        ser.close()
    except Exception:
        pass
    cap.release()
    cv2.destroyAllWindows()
    print("[ReCred] Done.")
