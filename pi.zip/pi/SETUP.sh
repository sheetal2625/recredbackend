# ReCred – Raspberry Pi Setup
# ================================

# 1. Activate your YOLO virtualenv
source ~/yolo-venv2/bin/activate

# 2. Install dependencies
pip install pyserial qrcode pillow numpy opencv-python ultralytics --break-system-packages

# 3. Find Arduino serial port (plug UNO in first)
ls /dev/ttyACM* /dev/ttyUSB*
# → use whichever shows up (usually /dev/ttyACM0)
# → update SERIAL_PORT in recred_pi.py if different

# 4. Update SERVER_URL in recred_pi.py to your Railway URL
# e.g.  SERVER_URL = "https://recred-production.up.railway.app"

# 5. Run
export QT_QPA_PLATFORM=xcb
python recred_pi.py

# ── Controls ───────────────────────────────────
# Ctrl+Q       : exit
# Reset button on Arduino : claim points (shows QR)
